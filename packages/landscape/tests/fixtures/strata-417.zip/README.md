# STRATA Spielkarte v1

Höhen sind bereits in Metern skaliert. Nicht erneut mit heightScaleBaked multiplizieren.
Rasterursprung: Südwest (-260, +320 Z); Zeilen laufen nach Norden (-Z).
Import: importGameMap(blob) aus src/landscape/game-map.js. Alle Binärdaten/Wege werden erneut geprüft.
heightAt / walkableAt / createTerrainMesh stehen ohne WebGL bereit.
Navigation gilt für Makrogelände, Einheitenradius 0; Hindernisse und Einheitenradien separat berücksichtigen.
Keine Materialien, Texturen, Kamera oder Lichtparameter enthalten.
SDK-Dateien sind zum manuellen Übernehmen beigefügt; der Import führt niemals ZIP-Code aus.
