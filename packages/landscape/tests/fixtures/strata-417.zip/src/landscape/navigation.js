// Gameplay geometry, independent of materials, camera and render LOD.
export const MAX_SLOPE=35;
export const MAX_HEIGHT_SCALE=1.8;
export const DEFAULT_PATH_WIDTH=12;
export const PATH_WIDTH_LIMITS=[6,24];
export const CORRIDOR_PADDING=4; // > diagonal of a 2 m macro cell
export const CORRIDOR_SHOULDER=24;
const WIDTH=520,LENGTH=640;
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
export const pathWidth=value=>Number.isFinite(value)?clamp(value,...PATH_WIDTH_LIMITS):DEFAULT_PATH_WIDTH;

// One compatible C1 height profile for EVERY route, including crossings, loops
// and branch junctions. Its gradient is independent of curve radius/direction.
// At upperHeight<=128 and scale<=1.8: max grade <= .569 < tan(35deg).
export function corridorHeight(y,upperHeight) {
  const t=clamp((y+280)/560,0,1);
  return 10+(upperHeight-10)*t*t*(3-2*t);
}
export function navigationRules(width=DEFAULT_PATH_WIDTH) {
  return {maxSlope:MAX_SLOPE,maxHeightScale:MAX_HEIGHT_SCALE,pathWidth:pathWidth(width)};
}

export function createCorridorIndex(routes,width) {
  const radius=width/2,core=radius+CORRIDOR_PADDING;
  const reach=core+CORRIDOR_SHOULDER,cell=32,cols=Math.ceil(WIDTH/cell),rows=Math.ceil(LENGTH/cell);
  const buckets=Array.from({length:cols*rows},()=>[]),segments=[];
  for(const route of routes)for(let i=1;i<route.points.length;i++) {
    const a=route.points[i-1],b=route.points[i],dx=b.x-a.x,dy=b.y-a.y,length2=dx*dx+dy*dy;
    if(length2<1e-12)continue;
    const segment={x:a.x,y:a.y,dx,dy,length2};segments.push(segment);
    const x0=clamp(Math.floor((Math.min(a.x,b.x)-reach+WIDTH/2)/cell),0,cols-1);
    const x1=clamp(Math.floor((Math.max(a.x,b.x)+reach+WIDTH/2)/cell),0,cols-1);
    const y0=clamp(Math.floor((Math.min(a.y,b.y)-reach+LENGTH/2)/cell),0,rows-1);
    const y1=clamp(Math.floor((Math.max(a.y,b.y)+reach+LENGTH/2)/cell),0,rows-1);
    for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)buckets[y*cols+x].push(segment);
  }
  if(!segments.length)throw Error('Wegenetz fehlt.');
  function distance(x,y) {
    const bx=clamp(Math.floor((x+WIDTH/2)/cell),0,cols-1),by=clamp(Math.floor((y+LENGTH/2)/cell),0,rows-1);
    let nearest=reach*reach;
    for(const s of buckets[by*cols+bx]) {
      const t=clamp(((x-s.x)*s.dx+(y-s.y)*s.dy)/s.length2,0,1);
      nearest=Math.min(nearest,(x-s.x-t*s.dx)**2+(y-s.y-t*s.dy)**2);
    }
    return Math.sqrt(nearest);
  }
  return {radius,core,reach,distance};
}
export function createCorridor(plan) {
  const maxGrade=(plan.upperHeight-10)*1.5/560*MAX_HEIGHT_SCALE;
  if(!Number.isFinite(maxGrade)||maxGrade<0||maxGrade>=Math.tan(MAX_SLOPE*Math.PI/180))throw Error('Höhenprofil überschreitet die konstruktive Weggarantie.');
  return {...createCorridorIndex(plan.routes,plan.navigation.pathWidth),height:y=>corridorHeight(y,plan.upperHeight)};
}

// Maximum slope of BOTH authoritative macro triangles, not central differences.
export function cellGrade(heights,nx,ny,i,j) {
  const a=j*(nx+1)+i,b=a+1,c=a+nx+1,d=c+1,dx=WIDTH/nx,dy=LENGTH/ny;
  return Math.max(Math.hypot((heights[b]-heights[a])/dx,(heights[c]-heights[a])/dy),
    Math.hypot((heights[d]-heights[c])/dx,(heights[d]-heights[b])/dy));
}

export async function buildNavigation(plan,heights,nx,ny,{yieldWork=async()=>{},progress=()=>{}}={}) {
  if(heights.length!==(nx+1)*(ny+1)||WIDTH/nx!==2||LENGTH/ny!==2)throw Error('Weggarantie benötigt das feste 2-m-Makroraster.');
  const corridor=createCorridor(plan),grid=new Float32Array(nx*ny*2);
  const limit=Math.tan(MAX_SLOPE*Math.PI/180),cellRadius=Math.hypot(WIDTH/nx,LENGTH/ny)/2;
  let corridorCells=0,maxCorridorGrade=0;
  for(let j=0;j<ny;j++) {
    for(let i=0;i<nx;i++) {
      const at=(j*nx+i)*2,grade=cellGrade(heights,nx,ny,i,j);
      if(!Number.isFinite(grade))throw Error('Ungültige Höhen im Navigationsraster.');
      const inCorridor=corridor.distance((i+.5)*WIDTH/nx-WIDTH/2,(j+.5)*LENGTH/ny-LENGTH/2)<=corridor.radius+cellRadius;
      grid[at]=grade;grid[at+1]=inCorridor?1:0;
      if(inCorridor) {
        corridorCells++;maxCorridorGrade=Math.max(maxCorridorGrade,grade*MAX_HEIGHT_SCALE);
        if(grade*MAX_HEIGHT_SCALE>limit+1e-5)throw Error('Interner Fehler: Korridor verletzt die Steigungsgarantie.');
      }
    }
    if(j%32===31){progress((j+1)/ny*.7);await yieldWork();}
  }
  // Final assertion, NEVER a repair/retry: all protected cells (including every
  // branch/loop/end disc) must belong to a border-to-border walkable component.
  const seen=new Uint8Array(nx*ny),queue=new Int32Array(nx*ny);let head=0,tail=0;
  const visit=k=>{if(!seen[k]&&grid[k*2+1]&&grid[k*2]*MAX_HEIGHT_SCALE<=limit+1e-5){seen[k]=1;queue[tail++]=k;}};
  for(let i=0;i<nx;i++)if(grid[i*2+1])visit(i);
  while(head<tail) {
    const k=queue[head++],x=k%nx,y=Math.floor(k/nx);
    if(x>0)visit(k-1);if(x+1<nx)visit(k+1);if(y>0)visit(k-nx);if(y+1<ny)visit(k+nx);
    if(head%16384===0){progress(.7+.29*head/(nx*ny));await yieldWork();}
  }
  let north=false;
  for(let k=0;k<nx*ny;k++) {
    if(grid[k*2+1]&&!seen[k])throw Error('Interner Fehler: Ein Ast des Wegenetzes ist nicht verbunden.');
    if(k>=(ny-1)*nx&&grid[k*2+1]&&seen[k])north=true;
  }
  if(!north||!corridorCells)throw Error('Interner Fehler: Süd–Nord-Korridor fehlt.');
  progress(1);
  return {grid,report:{...plan.navigation,corridorCells,connected:true,routeCount:plan.routes.length,
    maxCorridorSlope:Math.atan(maxCorridorGrade)*180/Math.PI}};
}
